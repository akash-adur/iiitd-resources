// gcc -o 2.4 2.4.c -lpthread 

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h> 
#include <fcntl.h>  
#include <sys/stat.h> 

#define NUM_SLOTS 3 
#define NUM_THREADS 5 

#define SEM_NAME "/pool_sem_example"
sem_t *pool_sem;

void* worker_thread(void* arg) {
    int id = *(int*)arg;
    printf("Thread %d: --- Waiting for a slot...\n", id);
    fflush(stdout);
    if (sem_wait(pool_sem) != 0) {
        perror("sem_wait failed");
        return NULL;
    }
    printf("Thread %d: ===> Got a slot.\n", id);
    fflush(stdout);
    sleep(1);

    printf("Thread %d: <=== Releasing a slot.\n", id);
    fflush(stdout);
    if (sem_post(pool_sem) != 0) {
        perror("sem_post failed");
        return NULL;
    }

    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    int thread_ids[NUM_THREADS];

    printf("Main: Initializing semaphore with %d slots.\n", NUM_SLOTS);

    sem_unlink(SEM_NAME);

    pool_sem = sem_open(SEM_NAME, O_CREAT | O_EXCL, 0644, NUM_SLOTS);

    if (pool_sem == SEM_FAILED) {
        perror("Failed to initialize semaphore (sem_open)");
        return 1;
    }

    printf("Main: Creating %d worker threads...\n", NUM_THREADS);


    for (int i = 0; i < NUM_THREADS; i++) {
        thread_ids[i] = i + 1; 

        if (pthread_create(&threads[i], NULL, worker_thread, &thread_ids[i]) != 0) {
            perror("Failed to create thread");
            return 1;
        }
    }

    printf("Main: All threads created. Waiting for them to join...\n");

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("Main: All threads have finished.\n");

    if (sem_close(pool_sem) != 0) {
        perror("sem_close failed");
    }

    if (sem_unlink(SEM_NAME) != 0) {
        perror("sem_unlink failed");
    }

    printf("Main: Semaphore closed and unlinked. Exiting.\n");

    return 0;
}