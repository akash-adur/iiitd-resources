#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_ITEMS 10

int buffer;
int item_count = 0;

pthread_mutex_t mutex;

pthread_cond_t cond_full;

pthread_cond_t cond_empty;

void* producer(void* arg) {
    for (int i = 1; i <= NUM_ITEMS; i++) {
        pthread_mutex_lock(&mutex);
        while (item_count == 1) {
            printf("Producer: Buffer is FULL. Waiting...\n");
            fflush(stdout);
            pthread_cond_wait(&cond_full, &mutex);
        }
        buffer = i;
        item_count = 1;

        printf("Producer: Produced item %d\n", buffer);
        fflush(stdout);
        pthread_cond_signal(&cond_empty);
        pthread_mutex_unlock(&mutex);
        usleep(50 * 1000);
    }

    printf("Producer: Finished. Exiting.\n");
    fflush(stdout);
    return NULL;
}

void* consumer(void* arg) {
    for (int i = 0; i < NUM_ITEMS; i++) {
        pthread_mutex_lock(&mutex);
        while (item_count == 0) {
            printf("Consumer: Buffer is EMPTY. Waiting...\n");
            fflush(stdout);
            pthread_cond_wait(&cond_empty, &mutex);
        }
        int item = buffer;
        item_count = 0;

        printf("Consumer: Consumed item %d\n", item);
        fflush(stdout);
        pthread_cond_signal(&cond_full);
        pthread_mutex_unlock(&mutex);
        usleep(100 * 1000);
    }

    printf("Consumer: Finished. Exiting.\n");
    fflush(stdout);
    return NULL;
}

int main() {
    pthread_t tid_producer, tid_consumer;
    printf("Main: Initializing mutex and condition variables...\n");
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond_full, NULL);
    pthread_cond_init(&cond_empty, NULL);
    printf("Main: Starting producer and consumer threads...\n");
    if (pthread_create(&tid_producer, NULL, producer, NULL) != 0) {
        perror("Failed to create producer thread");
        return 1;
    }
    if (pthread_create(&tid_consumer, NULL, consumer, NULL) != 0) {
        perror("Failed to create consumer thread");
        return 1;
    }

    pthread_join(tid_producer, NULL);
    pthread_join(tid_consumer, NULL);
    printf("Main: Threads joined. Cleaning up...\n");
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond_full);
    pthread_cond_destroy(&cond_empty);
    printf("Main: All items produced and consumed. Exiting.\n");

    return 0;
}
