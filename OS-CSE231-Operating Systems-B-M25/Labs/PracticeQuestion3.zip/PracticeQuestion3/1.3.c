#include <stdio.h>    
#include <stdlib.h>   
#include <unistd.h>   
#include <sys/types.h> 
#include <sys/wait.h> 
#include <string.h>  
// A buffer size for our string
#define BUFFER_SIZE 256

void reverse_string(char *str) {
    if (str == NULL) {
        return;
    }

    int len = strlen(str);
    if (len < 2) {
        return;
    }

    char *start = str;
    char *end = str + len - 1; // Point to the last char, not the null terminator
    char temp;

    // Swap characters from the ends moving towards the center
    while (start < end) {
        // Swap
        temp = *start;
        *start = *end;
        *end = temp;

        // Move pointers
        start++;
        end--;
    }
}

int main() {
    int pipe_fd[2]; 

    pid_t pid;
    char buffer[BUFFER_SIZE];
    if (pipe(pipe_fd) == -1) {
        perror("pipe"); // Reports the error
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid < 0) {
        // --- Fork Failed ---
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        close(pipe_fd[0]);

        printf("Parent: Enter a string: ");
        fflush(stdout); // Ensure prompt appears before input
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        // Send the string to the child
        printf("Parent: Sending '%s' to child...\n", buffer);
        fflush(stdout);
        if (write(pipe_fd[1], buffer, strlen(buffer) + 1) == -1) {
             perror("Parent: write");
             // Clean up before exiting
             close(pipe_fd[1]);
             exit(EXIT_FAILURE);
        }
        close(pipe_fd[1]);

        // Wait for the child process to finish
        wait(NULL);
        printf("Parent: Child finished. Exiting.\n");

    } else {
        close(pipe_fd[1]);
        ssize_t bytes_read = read(pipe_fd[0], buffer, BUFFER_SIZE);

        if (bytes_read == -1) {
            perror("Child: read");
            close(pipe_fd[0]);
            exit(EXIT_FAILURE);
        } else if (bytes_read == 0) {
            printf("Child: No data received from parent.\n");
        } else {
            reverse_string(buffer);
            printf("Child: Received and reversed string: %s\n", buffer);
            fflush(stdout);
        }
        close(pipe_fd[0]);
        exit(0);
    }

    return 0;
}