#include <stdio.h>
#include <stdlib.h>
#include <string.h>   
#include <pthread.h> 
#include <unistd.h> 

char message[100] = {0};

void* write_hello(void* arg) {
    const char* hello_str = "Hello World";
    int len = strlen(hello_str);

    for (int i = 0; i < len; i++) {
        message[i] = hello_str[i];
        usleep(1); 
    }
    return NULL;
}

void* write_goodbye(void* arg) {
    const char* goodbye_str = "Goodbye";
    int len = strlen(goodbye_str);

    for (int i = 0; i < len; i++) {
        message[i] = goodbye_str[i]; // Write one character
        usleep(1); // "Yield" to the other thread (1 microsecond)
    }

    return NULL;
}

int main() {
    pthread_t tid1, tid2; // Thread IDs

    printf("Starting threads. The final message will be unpredictable...\n");

    // Create the first thread to run write_hello
    if (pthread_create(&tid1, NULL, write_hello, NULL) != 0) {
        perror("Failed to create thread 1");
        return 1;
    }

    // Create the second thread to run write_goodbye
    if (pthread_create(&tid2, NULL, write_goodbye, NULL) != 0) {
        perror("Failed to create thread 2");
        return 1;
    }
    // Wait for the first thread to finish
    pthread_join(tid1, NULL);
    // Wait for the second thread to finish
    pthread_join(tid2, NULL);
    printf("Threads have finished and been joined.\n");
    printf("Final message: '%s'\n", message);
    return 0;
}
