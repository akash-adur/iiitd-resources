#include <stdio.h>     
#include <stdlib.h>  
#include <unistd.h>  
#include <signal.h>  
#include <sys/types.h> 
#include <sys/wait.h>

volatile sig_atomic_t paused = 0;

void handle_sigusr1(int sig) {
    paused = !paused;
}

void child_process_main() {
    if (signal(SIGUSR1, handle_sigusr1) == SIG_ERR) {
        perror("Child: Failed to install SIGUSR1 handler");
        exit(EXIT_FAILURE);
    }

    while (1) {
        if (!paused) {
            printf("Working\n");
            fflush(stdout);
        }
        sleep(1);
    }
}


void parent_process_main(pid_t child_pid) {
    printf("Parent (PID: %d): Started child (PID: %d)\n", getpid(), child_pid);
    fflush(stdout);
    sleep(3);
    printf("Parent: Sending SIGUSR1 to pause child.\n");
    fflush(stdout);
    kill(child_pid, SIGUSR1);  
    printf("Parent: Paused child.\n");
    fflush(stdout);
    sleep(3);
    printf("Parent: Sending SIGUSR1 to unpause child.\n");
    fflush(stdout);
    kill(child_pid, SIGUSR1);
    printf("Parent: Unpaused child.\n");
    fflush(stdout);
    sleep(2);
    printf("Parent: Sending SIGTERM to terminate child.\n");
    fflush(stdout);
    kill(child_pid, SIGTERM);
    wait(NULL);
    printf("Parent: Child process reaped. Exiting.\n");
    fflush(stdout);
}

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        // --- Fork Failed ---
        perror("fork failed");
        exit(EXIT_FAILURE);

    } else if (pid == 0) {
        child_process_main();

    } else {
        // --- Parent Process ---
        parent_process_main(pid);
    }

    return 0;
}