#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h> 
pthread_mutex_t mutex;

pthread_cond_t cond;

volatile int work_ready = 0;

void* worker_thread(void* arg) {
    printf("Worker: Thread started. Locking mutex...\n");
    fflush(stdout);

    pthread_mutex_lock(&mutex);
    printf("Worker: Mutex locked. Checking work_ready flag...\n");
    fflush(stdout);

    while (work_ready == 0) {
        printf("Worker: work_ready is 0. Calling pthread_cond_wait()...\n");
        fflush(stdout);
        pthread_cond_wait(&cond, &mutex);
        printf("Worker: Woke up. Re-checking work_ready...\n");
        fflush(stdout);
    }
    printf("Worker: work_ready is 1. Work started!\n");
    fflush(stdout);
    pthread_mutex_unlock(&mutex);
    printf("Worker: Work finished. Mutex unlocked. Exiting.\n");
    fflush(stdout);

    return NULL;
}

int main() {
    pthread_t tid;
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond, NULL);

    printf("Main: Creating worker thread...\n");
    fflush(stdout);
    if (pthread_create(&tid, NULL, worker_thread, NULL) != 0) {
        perror("Failed to create thread");
        return 1;
    }
    printf("Main: Sleeping for 2 seconds to let worker start...\n");
    fflush(stdout);
    sleep(2);
    printf("Main: Locking mutex to signal worker...\n");
    fflush(stdout);
    pthread_mutex_lock(&mutex);
    printf("Main: Setting work_ready = 1\n");
    fflush(stdout);
    work_ready = 1;
    printf("Main: Calling pthread_cond_signal()...\n");
    fflush(stdout);
    pthread_cond_signal(&cond);
    pthread_mutex_unlock(&mutex);
    printf("Main: Mutex unlocked.\n");
    fflush(stdout);
    printf("Main: Waiting for worker thread to join...\n");
    fflush(stdout);
    pthread_join(tid, NULL);
    printf("Main: Worker joined. Cleaning up and exiting.\n");
    fflush(stdout);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);

    return 0;
}
