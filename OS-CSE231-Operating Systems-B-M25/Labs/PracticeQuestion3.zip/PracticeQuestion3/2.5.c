#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#define SEM_NAME "/task_A_done_sem"
sem_t *task_A_done;

void* thread_A_func(void* arg) {
    printf("Thread A: Performing task (sleeping for 2s)...\n");
    fflush(stdout);
    sleep(2);
    printf("Thread A: Task finished. Signaling Thread B.\n");
    fflush(stdout);
    if (sem_post(task_A_done) != 0) {
        perror("Thread A: sem_post failed");
    }

    return NULL;
}


void* thread_B_func(void* arg) {
    printf("Thread B: Waiting for Task A to finish...\n");
    fflush(stdout);
    if (sem_wait(task_A_done) != 0) {
        perror("Thread B: sem_wait failed");
        return NULL;
    }

    printf("Thread B: Received signal. Starting its own task.\n");
    fflush(stdout);

    return NULL;
}

int main() {
    pthread_t tid_A, tid_B; 
    sem_unlink(SEM_NAME);
    task_A_done = sem_open(SEM_NAME, O_CREAT | O_EXCL, 0644, 0);
    if (task_A_done == SEM_FAILED) {
        perror("Failed to initialize semaphore (sem_open)");
        return 1;
    }
    printf("Main: Semaphore initialized to 0. Creating threads.\n");
    if (pthread_create(&tid_B, NULL, thread_B_func, NULL) != 0) {
        perror("Failed to create Thread B");
        return 1;
    }
    sleep(1);
    if (pthread_create(&tid_A, NULL, thread_A_func, NULL) != 0) {
        perror("Failed to create Thread A");
        return 1;
    }
    printf("Main: Waiting for threads to join...\n");
    pthread_join(tid_A, NULL);
    pthread_join(tid_B, NULL);
    printf("Main: Both threads have finished.\n");
    sem_close(task_A_done);
    sem_unlink(SEM_NAME);
    printf("Main: Semaphore cleaned up. Exiting.\n");
    return 0;
}
