#include <stdio.h>     
#include <stdlib.h> 
#include <unistd.h> 
#include <signal.h>   
#include <sys/types.h>
#include <sys/wait.h>

sig_atomic_t sig_received = 0;

void sig_handler(int sig) {
    sig_received = 1;
}

void child_process_main() {
    pid_t parent_pid = getppid();
    int rounds = 5;

    if (signal(SIGUSR1, sig_handler) == SIG_ERR) {
        perror("Child: Failed to install SIGUSR1 handler");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < rounds; i++) {
        
        sig_received = 0;
        while (!sig_received) {
            pause();
        }
        printf("Ping!\n");
        fflush(stdout);

        kill(parent_pid, SIGUSR2);
    }

    printf("Child: 5 rounds complete. Exiting.\n");
    fflush(stdout);
    exit(0);
}

void parent_process_main(pid_t child_pid) {
    int rounds = 5;

    // Install the handler for SIGUSR2 ("Pong")
    if (signal(SIGUSR2, sig_handler) == SIG_ERR) {
        perror("Parent: Failed to install SIGUSR2 handler");
        // If we fail, we should clean up the child
        kill(child_pid, SIGTERM);
        wait(NULL);
        exit(EXIT_FAILURE);
    }

    sleep(1);

    for (int i = 0; i < rounds; i++) {
        printf("Parent: Sending Ping (%d/5)...\n", i + 1);
        fflush(stdout);

        sig_received = 0; 
        kill(child_pid, SIGUSR1);

        while (!sig_received) {
            pause(); 
        }
        printf("Pong!\n");
        fflush(stdout);
        if (i < rounds - 1) {
            sleep(1);
        }
    }

    printf("Parent: 5 rounds complete.\n");
    fflush(stdout);

    wait(NULL);
    printf("Parent: Child reaped. Exiting.\n");
    fflush(stdout);
}

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        // --- Fork Failed ---
        perror("fork failed");
        exit(EXIT_FAILURE);

    } else if (pid == 0) {
        // --- Child Process ---
        child_process_main();

    } else {
        // --- Parent Process ---
        parent_process_main(pid);
    }

    return 0;
}
