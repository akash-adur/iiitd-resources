#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>

#define MAX_PATH_LEN 1024

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <directory_path>\n", argv[0]);
        return 1;
    }

    const char *dir_path = argv[1];

    DIR *dir = opendir(dir_path);
    if (dir == NULL) {
        perror("Error opening directory");
        return 1;
    }

    struct dirent *entry;
    struct stat file_stat;
    char full_path[MAX_PATH_LEN];

    printf("%-20s %-10s %-20s\n", "Inode", "Size (Bytes)", "File Name");
    printf("----------------------------------------------------\n");
    while ((entry = readdir(dir)) != NULL) {
        
        // Construct the full path: "directory_path/filename"
        // This is crucial because 'stat' needs the full address, 
        // not just the name inside the folder.
        int needed = snprintf(full_path, MAX_PATH_LEN, "%s/%s", dir_path, entry->d_name);
        
        if (needed >= MAX_PATH_LEN) {
            fprintf(stderr, "Warning: Path too long for %s\n", entry->d_name);
            continue;
        }

        // 4. Retrieve metadata using stat()
        if (stat(full_path, &file_stat) == -1) {
            perror("stat");
            continue;
        }
        // ls -i typically shows the Inode number.
        // The prompt specifically asked for File Name and Size.
        // We print: Inode (for ls -i accuracy), Size, and Name.
        printf("%-20lu %-10ld %s\n", 
               (unsigned long)file_stat.st_ino, 
               (long)file_stat.st_size, 
               entry->d_name);
    }

    closedir(dir);

    return 0;
}