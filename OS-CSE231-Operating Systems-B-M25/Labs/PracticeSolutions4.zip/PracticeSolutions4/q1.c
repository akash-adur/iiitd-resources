#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>

typedef struct {
    int id;
    int track;
    int sector;
    int visited;
} Request;

// Function to calculate total cost based on prompt formulas
// Seek Time = abs(diff track) * 10
// Rotational Latency = abs(diff sector) * 2
int calculate_cost(int current_track, int current_sector, int target_track, int target_sector) {
    int seek_time = abs(current_track - target_track) * 10;
    int rot_latency = abs(current_sector - target_sector) * 2;
    return seek_time + rot_latency;
}

int main() {
    int head_track, head_sector;
    Request requests[5];
    int i, count;

    if (scanf("%d %d", &head_track, &head_sector) != 2) {
        fprintf(stderr, "Error reading head position.\n");
        return 1;
    }

    for (i = 0; i < 5; i++) {
        requests[i].id = i + 1;
        requests[i].visited = 0;
        if (scanf("%d %d", &requests[i].track, &requests[i].sector) != 2) {
            fprintf(stderr, "Error reading request %d.\n", i + 1);
            return 1;
        }
    }

    printf("--- SPTF Optimization Results ---\n");
    printf("Initial Position: Track %d, Sector %d\n\n", head_track, head_sector);
    printf("Order of Processing:\n");

    // We need to process 5 requests in total
    int total_accumulated_cost = 0;

    for (count = 0; count < 5; count++) {
        int best_index = -1;
        int min_cost = INT_MAX;
        for (i = 0; i < 5; i++) {
            if (!requests[i].visited) {
                int current_cost = calculate_cost(head_track, head_sector, requests[i].track, requests[i].sector);
                if (current_cost < min_cost) {
                    min_cost = current_cost;
                    best_index = i;
                }
            }
        }

        if (best_index != -1) {
            requests[best_index].visited = 1;
            printf("Process Request ID %d [Track: %d, Sector: %d] -> Cost: %d\n", 
                requests[best_index].id, 
                requests[best_index].track, 
                requests[best_index].sector, 
                min_cost);
            head_track = requests[best_index].track;
            head_sector = requests[best_index].sector;
            
            total_accumulated_cost += min_cost;
        }
    }

    printf("\nTotal Seek + Latency Cost for all operations: %d\n", total_accumulated_cost);

    return 0;
}