#include <stdio.h>

int disk_bitmap = 0;

// Helper function to print bitmap in Hex and Binary
void print_status() {
    printf("Bitmap (Hex): 0x%08X | (Binary): ", disk_bitmap);
    // Printing binary from MSB (31) to LSB (0)
    for (int i = 31; i >= 0; i--) {
        printf("%d", (disk_bitmap >> i) & 1);
        if (i % 4 == 0 && i != 0) printf(" ");
    }
    printf("\n");
}

int allocate_block() {
    // Iterate through bits 0 to 31
    for (int i = 0; i < 32; i++) {
        if ( !((disk_bitmap >> i) & 1) ) {
            disk_bitmap |= (1 << i);
            return i;
        }
    }
    
    printf("Error: Disk is full.\n");
    return -1;
}

void free_block(int block_index) {
    if (block_index < 0 || block_index > 31) {
        printf("Error: Invalid block index %d\n", block_index);
        return;
    }

    if ( !((disk_bitmap >> block_index) & 1) ) {
        printf("Block %d is already free.\n", block_index);
        return;
    }

    disk_bitmap &= ~(1 << block_index);
    printf("Block %d freed.\n", block_index);
}

int main() {
    printf("--- Initial State ---\n");
    print_status();
    printf("\n");

    int b1 = allocate_block();
    printf("Allocated Block: %d\n", b1);
    print_status();

    int b2 = allocate_block();
    printf("Allocated Block: %d\n", b2);
    print_status();

    int b3 = allocate_block();
    printf("Allocated Block: %d\n", b3);
    print_status();
    
    printf("\n--- Freeing a Block ---\n");
    
    free_block(b2);
    print_status();

    printf("\n--- Allocating One More to Verify Reuse ---\n");
    int b4 = allocate_block();
    printf("Allocated Block: %d\n", b4);
    print_status();

    return 0;
}