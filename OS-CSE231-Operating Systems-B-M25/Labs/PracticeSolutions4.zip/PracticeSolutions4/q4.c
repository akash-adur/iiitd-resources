#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>

int main() {
    int total_tracks, current_head, n;
    int *requests;
    int *visited;
    int total_movement = 0;

    printf("Enter total number of tracks: ");
    if (scanf("%d", &total_tracks) != 1) return 1;

    printf("Enter current head position: ");
    if (scanf("%d", &current_head) != 1) return 1;
    printf("Enter number of requests: ");
    if (scanf("%d", &n) != 1) return 1;

    requests = (int *)malloc(n * sizeof(int));
    visited = (int *)calloc(n, sizeof(int));

    printf("Enter the request queue (separate by space): ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &requests[i]);
    }

    printf("\n--- SSTF Simulation Start ---\n");
    printf("Sequence of service: ");

    for (int i = 0; i < n; i++) {
        int min_dist = INT_MAX;
        int target_index = -1;

        for (int j = 0; j < n; j++) {
            if (!visited[j]) {
                int distance = abs(current_head - requests[j]);
                
                if (distance < min_dist) {
                    min_dist = distance;
                    target_index = j;
                }
            }
        }

        if (target_index != -1) {
            visited[target_index] = 1;
            
            total_movement += min_dist;
            
            current_head = requests[target_index];
            
            printf("%d ", current_head);
        }
    }

    printf("\n\nTotal Head Movement: %d\n", total_movement);

    free(requests);
    free(visited);

    return 0;
}