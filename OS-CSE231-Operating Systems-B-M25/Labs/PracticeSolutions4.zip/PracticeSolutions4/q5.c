#include <stdio.h>

int main() {
    // Input: Disk Map 0xF0F0
    // Binary representation: 1111 0000 1111 0000
    // 1 = Used, 0 = Free
    unsigned int disk_map = 0xF0F0;
    int free_count = 0;
    int total_blocks = 16; // As specified in the prompt

    printf("Analyzing Disk Map: 0x%X\n", disk_map);

    for (int i = 0; i < total_blocks; i++) {
        int bit_value = (disk_map >> i) & 1;

        // If the bit is 0, the block is free
        if (bit_value == 0) {
            free_count++;
        }
    }
    printf("Total Free Blocks: %d\n", free_count);

    return 0;
}